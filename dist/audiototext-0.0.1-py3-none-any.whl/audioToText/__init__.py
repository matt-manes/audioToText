from .audioToText import (cleanUp, getTextFromMp3, getTextFromUrl,
                          getTextFromWav)

""" FFMPEG needs to be installed and in your PATH for this to work. """
cleanUp()
