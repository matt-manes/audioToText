from .audioToText import getTextFromUrl, getTextFromMp3, getTextFromWav, cleanUp
""" FFMPEG needs to be installed and in your PATH for this to work. """
cleanUp()
