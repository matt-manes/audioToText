""" FFMPEG needs to be installed and in your PATH for this to work. """
from .mp3ToText import getText, cleanUp
cleanUp()