from .mp3ToText import getText, cleanUp
""" FFMPEG needs to be installed and in your PATH for this to work. """
cleanUp()
